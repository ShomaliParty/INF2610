/*
 * Init Lab - answers-q5.h
 * 
 * Ecole polytechnique de Montreal, 2018
 */

#ifndef _ANSWERS_Q5_H
#define _ANSWERS_Q5_H

// -----------------------------------------------------------------
// Reportez ici les réponses que vous avez trouvées à la question 5.
// -----------------------------------------------------------------

// Report here the answer for question 5. a)
char Q5_ANS_A[] = "/tmp/filewriter_secret_2979a57e117c5e2c"; //TODO

// Report here the answer for question 5. b)
char Q5_ANS_B[] = "/tmp/filewriter_secret_child_86cf2d562c25aa09"; //TODO

// Report here the answer for question 5. c)
char Q5_ANS_C[] = "4d11dfed318fde6c645a147959e9ab4dd586e253df7663dcf593a0ec30503c0e"; //TODO

// Report here the answer for question 5. d)
char Q5_ANS_D[] = "fputs"; //TODO

// Report here the answer for question 5. e)
char Q5_ANS_E[] = "WAIT"; //TODO

#endif